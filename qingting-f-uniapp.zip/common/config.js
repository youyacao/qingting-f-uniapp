module.exports = {
	base_url:process.env.NODE_ENV === 'development' ? 'https://qingtingapi.youyacao.com/api/v1/' : 'https://qingtingapi.youyacao.com/api/v1/',
	image_base:'http://qingtingcun.youyacao.com/'
}