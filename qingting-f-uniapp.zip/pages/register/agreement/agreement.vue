<template>
	<view class="body">
		<web-view :webview-styles="webviewStyles" src="https://songshu.youyacao.com/detail/162.html"></web-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				webviewStyles: {}
			};
		}
	}
</script>

<style lang="scss" scoped>

</style>
